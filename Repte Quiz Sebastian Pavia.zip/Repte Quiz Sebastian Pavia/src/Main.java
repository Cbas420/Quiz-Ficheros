import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;

/**
 * Metodo principal el cual realiza todas las llamadas de otros metodos para la ejecucion del programa.
 */
public class Main {
    public static void main(String[] args) {

        String[] preguntasTotales;
        int numeroPreguntas = pedirPreguntas();
        int intentos = 0;
        int aciertos = 0;
        int porcentaje;
        int[] preguntasSeleccionadas;
        String respuesta;
        String respuestaRepetir;
        String nombreUsuario;
        boolean respuestaBoolean;
        boolean respuestaRepetirJuegoBoolean;
        boolean comprobacionRespuesta;
        boolean [] respuestasTotales;


        do {

            LocalDateTime fechaHoraActual = LocalDateTime.now();
            nombreUsuario = pedirNombreUsuario();
            preguntasTotales = preguntasAlmacenadas();
            preguntasSeleccionadas = seleccionarPreguntas(numeroPreguntas, preguntasTotales);
            respuestasTotales = respuestasAlmacenadas();

            for (int i = 0; i < preguntasSeleccionadas.length; i++) {
                respuesta = realizarPreguntas(preguntasTotales, i, preguntasSeleccionadas);
                respuestaBoolean = convertirRespuestaEnBoolean(respuesta);
                comprobacionRespuesta = evaluarRespuesta(respuestaBoolean, respuestasTotales, i, preguntasSeleccionadas);
                intentos = contarIntentos(intentos);
                aciertos = contarAciertos(aciertos, comprobacionRespuesta);
            }
            porcentaje = calcularPorcentaje(intentos, aciertos);
            mostrarMensajeEspecifico(porcentaje);
            respuestaRepetir = preguntarRepetirJuego();
            respuestaRepetirJuegoBoolean = convertirRespuestaRepetirEnBoolean(respuestaRepetir);
            guardarDatosUsuario(nombreUsuario, intentos, aciertos, fechaHoraActual);
        } while (respuestaRepetirJuegoBoolean);
    }

    /**
     *Metodo para obtener el nombre del usuario de la sesion actual.
     * @return Nombre del usuario en forma de variable String
     */
    private static String pedirNombreUsuario() {
        String nombreUsuario;
        System.out.println("Cual es tu nombre?: ");
        nombreUsuario = Teclat.llegirString();
        return nombreUsuario;
    }

    /**
     * Metodo para guardar los datos del usuario de la sesion actual en un fichero
     * @param nombreUsuario Nombre insertado por el mismo usuario
     * @param intentos Numero de los intentos totales
     * @param aciertos Numero de todos los intentos con respuesta correcta
     * @param fechaHoraActual Variable con la fecha y hora actual
     */
    private static void guardarDatosUsuario (String nombreUsuario, int intentos, int aciertos, LocalDateTime fechaHoraActual) {
        String newFile = "src/resources/estadisticas.txt";
        String[] DatosUsuario = {"Nombre de Usuario: " + nombreUsuario, " -Intentos: " + intentos, " -Aciertos: " + aciertos, " -Fecha y Hora: " + fechaHoraActual};

        Path ruta = Paths.get("src/resources/estadisticas.txt");

        try {
            for(String myString : DatosUsuario) {
                Files.writeString(ruta, myString, StandardOpenOption.APPEND);
                Files.writeString(ruta, System.lineSeparator(), StandardOpenOption.APPEND);
            }
        } catch (IOException e) {
            System.out.println("Error en la escritura del fichero!");
        }
    }

    /**
     * Metodo para rellenar un array con todas las preguntas del programa, leyendolas de un archivo de texto con el nombre "preguntasQuiz.txt"
     * @return La variable ya rellenada de todas las preguntas del programa.
     */
    private static String[] preguntasAlmacenadas() {
        String[] preguntasTotales = new String[20];
        String archivoPreguntas = "src/resources/preguntasQuiz.txt";
        String line;
        int contador = 0;
        BufferedReader br = null;

        try {
            br = new BufferedReader(new FileReader(archivoPreguntas));
            while ( (line = br.readLine()) != null ) {
                preguntasTotales[contador] = line;
                contador++;
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado!");
        } catch (IOException e) {
            System.out.println("Error en la escritura del metodo!");
        } finally {
            try {
                br.close();
            } catch (IOException e) {
                System.out.println("Error en el cierre de escritura del fichero!");
            }
        }
        return preguntasTotales;
    }

    /*
     *Metodo para realizar un test del metodo preguntasAlmacenadas()
     */
    public static String[] testPreguntasAlmacenadas() {
        return preguntasAlmacenadas();
    }

    /**
     * Metodo para rellenar un array con todas las respuestas del programa, leyendolas de un archivo de texto con el nombre "respuestasQuiz.txt"
     * @return La variable ya rellenada de todas las respuestas del programa.
     */
    private static boolean[] respuestasAlmacenadas() {
        boolean[] respuestasTotales = new boolean[20];
        String archivoRespuestas = "src/resources/respuestasQuiz.txt";
        String line;
        int contador = 0;
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(archivoRespuestas));
            while ( (line = br.readLine()) != null ) {
                respuestasTotales[contador] = Boolean.valueOf(line);
                contador++;
            }
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado!");
        } catch (IOException e) {
            System.out.println("Error en la lectura del fichero!");
        } finally {
            try {
                br.close();
            } catch (IOException e) {
                System.out.println("Error en el cierre de escritura del fichero!");
            }
        }
        return respuestasTotales;
    }

    /**
     * Metodo para pedirle al usuario el numero de preguntas que desea responder.
     * @return Devuelve el numero de preguntas deseadas por el usuario en forma de int.
     */
    private static int pedirPreguntas() {
        int numeroPreguntas;
        System.out.println("Welcome to the Scott Pilgrim Movie Quiz. How many questions do you want to be asked?");
        numeroPreguntas = Teclat.llegirInt();
        return numeroPreguntas;
    }

    /**
     * Metodo para seleccionar un numero de preguntas al azar, cantidad que varia dependiendo del numero de preguntas que desea el usuario.
     * @param numeroPreguntas Variable que contiene el numero de preguntas que el usuario desea responder.
     * @param preguntasTotales Variable que contiene todas las preguntas del programa.
     * @return Las preguntas seleccionadas al azar.
     */
    private static int[] seleccionarPreguntas(int numeroPreguntas, String[] preguntasTotales) {
        int[] preguntasSeleccionadas = new int[numeroPreguntas];
        int preguntaAzar;
        boolean preguntaRepetida;

        for (int i = 0; i < preguntasSeleccionadas.length; i++) {
            do {
                preguntaRepetida = false;
                preguntaAzar = (int) (Math.random() * preguntasTotales.length);
                for (int j = 0; j < i; j++) {
                    if (preguntasSeleccionadas[j] == preguntaAzar ) {
                        preguntaRepetida = true;
                    }
                }
            }while (preguntaRepetida);
            preguntasSeleccionadas[i] = preguntaAzar;
        }
        return preguntasSeleccionadas;
    }

    /**
     * Metodo para obtener las respuestas de cada usuario.
     * @param preguntasTotales Parametro para acceder a todas las preguntas del programa.
     * @param i Iteracion actual del bucle del recorrido de las preguntas seleccionadas a mostrar.
     * @param preguntasSeleccionadas Array de las preguntas elegidas al azar a mostrar al usuario.
     * @return Devuelve la respuesta del usuario.
     */
    private static String realizarPreguntas (String [] preguntasTotales, int i, int[] preguntasSeleccionadas) { //
        String respuesta;
        boolean salir = false;
       do {
           System.out.println( preguntasTotales[preguntasSeleccionadas[i]]);
           respuesta = Teclat.llegirString();
           if (respuesta.equalsIgnoreCase("yes") || respuesta.equalsIgnoreCase("true") || respuesta.equalsIgnoreCase("no") || respuesta.equalsIgnoreCase("false"))
           {
               salir = true;
           }
       }while (!salir);
        return respuesta;
    }

    /**
     * Metodo para convertir la respuesta del usuario en forma de boolean.
     * @param respuesta Variable donde fue almacenada la respuesta del usuario en forma de String.
     * @return La respuesta del usuario en forma de boolean.
     */
    private static boolean convertirRespuestaEnBoolean (String respuesta) {
        boolean respuestaConvertida = true;
        respuesta = respuesta.toLowerCase();

        if (respuesta.equals("yes") || respuesta.equals("true")) {
            respuestaConvertida = true;
        } else if (respuesta.equals("no") || respuesta.equals("false")) {
            respuestaConvertida = false;
        }
        return respuestaConvertida;
    }

    /**
     * Metodo que cuenta cada uno de los intentos del usuario.
     * @param intentos Variable donde se almacenara el numero de intentos de respuesta del usuario.
     * @return La variable intentos actualizada.
     */
    private static int contarIntentos (int intentos) {
        intentos++;
        return intentos;
    }

    /**
     * Metodo para contar el numero de veces que el usuario ha respondido correctamente.
     * @param aciertos Variable donde se almacenara el numero de intentos del usuario.
     * @param comprobacionRespuesta Variable donde se verifica si el intento de respuesta del usuario es correcto o no.
     * @return La variable de aciertos actualizada.
     */
    private static int contarAciertos (int aciertos, boolean comprobacionRespuesta) {
        if (comprobacionRespuesta) {
            aciertos++;
        }
        return aciertos;
    }

    /**
     * Metodo para dar un mensaje unico dependiendo del porcentaje obtenido.
     * @param porcentaje Variable donde se almaceno el porcentaje de aciertos.
     */
    private static void mostrarMensajeEspecifico(int porcentaje) {
        if (porcentaje <= 33) {
            System.out.println("Bro you barely tried, you should learn a bit more");
        } else if (porcentaje <= 66 && porcentaje > 34) {
            System.out.println("Your knowledge is average, not bad");
        } else if (porcentaje < 99 && porcentaje > 67) {
            System.out.println("You actually know a lot! Well done");
        } else if (porcentaje >= 99) {
            System.out.println("You got every answer right, congratulations. I hope you didn't cheat though");
        }
    }

    /**
     * Metodo para verificar si la respuesta del usuario ha sido correcta, luego de haber sido transformada a boolean.
     * @param respuesta La respuesta del usuario en forma de boolean.
     * @param respuestasAlmacenadas Todas las respuestas de las preguntas del programa en forma de boolean.
     * @param i Iteracion actual del programa.
     * @param preguntasSeleccionadas Variable donde estan almacenadas todas las preguntas seleccionadas al azar para mostrar al usuario.
     * @return Devuelve un boolean para confirmar si la respuesta ha sido correcta o no.
     */
    private static boolean evaluarRespuesta(boolean respuesta, boolean [] respuestasAlmacenadas, int i, int[] preguntasSeleccionadas) {
        boolean acierto;
        if (respuesta == respuestasAlmacenadas[preguntasSeleccionadas[i]]) {
            acierto = true;
        } else {
            acierto = false;
        }
       return acierto;
    }

    /**
     * Metodo para calcular el porcentaje de la puntuacion del usuario.
     * @param intentos Variable donde cada intento fue almacenado cada intento de respuesta del usuario.
     * @param aciertos Variable donde se almacenaron todos los intentos con respuesta correcta.
     * @return El valor del porcentaje de aciertos sobre intentos obtenido.
     */
    private static int calcularPorcentaje(int intentos, int aciertos) {
        int porcentaje;
        porcentaje = (aciertos * 100) / intentos;
        System.out.println("Percentage of correct answers: " + porcentaje + "%");
        return porcentaje;
    }

    /*
     *Metodo para realizar un test del metodo calcularPorcentaje()
     */
    public static int testCalcularPorcentaje(int intentos, int aciertos){
        return calcularPorcentaje(intentos, aciertos);
    }


    /**
     * Metodo para preguntar al usuario si quiere repetir el juego.
     * @return La respuesta escrita por el usuario en forma de String.
     */
    private static String preguntarRepetirJuego() {
        String respuestaRepetir = "";
        System.out.println("Do you want to play again?");
        respuestaRepetir = Teclat.llegirString();
        return respuestaRepetir;
    }

    /**
     * Metodo para transformar la respuesta en boolean, con respecto a la pregunta de repetir el programa del Quiz en el metodo preguntaRepetirJuego();
     * @param respuestaRepetir Variable donde la respuesta del usuario fue almacenada en forma de String.
     * @return La respuesta del usuario en forma de Boolean.
     */
    private static boolean convertirRespuestaRepetirEnBoolean (String respuestaRepetir) {
        boolean respuestaRepetirConvertida = false;
        respuestaRepetir = respuestaRepetir.toLowerCase();

        if (respuestaRepetir.equals("yes") || respuestaRepetir.equals("true")) {
            respuestaRepetirConvertida = true;
        } else if (respuestaRepetir.equals("no") || respuestaRepetir.equals("false")) {
            respuestaRepetirConvertida = false;
        }
        return respuestaRepetirConvertida;
    }
}

