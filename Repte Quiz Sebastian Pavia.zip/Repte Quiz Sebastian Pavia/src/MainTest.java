import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @org.junit.jupiter.api.Test
    void calcularPorcentaje() {
        assertEquals(50, Main.testCalcularPorcentaje(10, 5));
    }

    @org.junit.jupiter.api.Test
    void preguntasAlmacenadas() {
        assertEquals("Did Michael Cera have to 'dumb down' his bass playing for the movie because he already knew how to play the bass?", Main.testPreguntasAlmacenadas()[0]);
    }


}